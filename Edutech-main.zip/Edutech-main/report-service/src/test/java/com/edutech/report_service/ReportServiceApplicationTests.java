package com.edutech.report_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
