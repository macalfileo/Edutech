package com.edutech.evaluation_service.model;

import lombok.Data;

@Data
public class Evaluation {
    private Long id;
    private String title;
    private String description;
}