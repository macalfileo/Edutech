package com.edutech.userprofile_service.model;

public enum Genero {
    // Enum para los géneros
    MASCULINO,
    FEMENINO,
    OTRO
}
