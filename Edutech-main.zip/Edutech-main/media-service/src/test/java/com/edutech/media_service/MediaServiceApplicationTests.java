package com.edutech.media_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
